CREATE PROCEDURE getRecord(IN in_id INT, OUT out_name VARCHAR(20), OUT out_age INT)
  BEGIN
	SELECT name, age 
    INTO out_name, out_age
    FROM student where id = in_id;
END;
